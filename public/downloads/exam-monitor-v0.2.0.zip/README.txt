Exam Integrity Monitor v0.2.0

1. Extract this folder. In Chrome, open chrome://extensions, enable Developer mode,
   click Load unpacked, and choose the extension folder INSIDE exam-monitor-v0.2.0.
   That extension folder must contain manifest.json. If Chrome says the manifest
   is missing, you selected the outer exam-monitor-v0.2.0 folder.
2. Verify the extension ID is amlfomdhhaklmifkneplnngkbaabibgp.
3. In PowerShell run:
   powershell -NoProfile -ExecutionPolicy Bypass -File native-host\install.ps1 -ExtensionId amlfomdhhaklmifkneplnngkbaabibgp
4. Reload the extension and open its popup. Pair with the code given by the professor.

Teacher service: http://127.0.0.1:8787
The Windows companion sends only foreground app categories and timestamps.
The extension sends incident categories, timestamps, and needed hostnames.