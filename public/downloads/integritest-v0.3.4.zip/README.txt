IntegriTest v0.3.4

1. In Downloads, right-click the ZIP and choose Extract All. Open the extracted
   folder showing both extension and native-host. Keep this folder in place.
2. In Chrome, open chrome://extensions, turn on Developer mode, and click
   Load unpacked. Open the extracted extension folder, then click Select Folder.
   Chrome's folder picker hides files, so only icons may be visible inside it.
   Do not select icons or the outer integritest-v0.3.4 folder.
3. Verify the extension ID is amlfomdhhaklmifkneplnngkbaabibgp.
4. In ordinary File Explorer, return to the extracted folder showing extension
   and native-host. Click the address bar, type powershell, and press Enter.
   In the PowerShell window run:
   powershell -NoProfile -ExecutionPolicy Bypass -File native-host\install.ps1 -ExtensionId amlfomdhhaklmifkneplnngkbaabibgp
   Look for the Registered message, then reload the extension.
5. Open the popup, pair with your own code, and open the registered Form.

Teacher service: https://integritest.dareugenio.workers.dev
The Windows companion sends only foreground app categories and timestamps.
The extension sends incident categories, timestamps, and needed hostnames.